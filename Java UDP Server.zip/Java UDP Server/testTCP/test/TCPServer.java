
import java.net.*;
import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TCPServer {

    public static void main(String args[]) {
        try {
            int serverPort = 7778; // the server port
            ServerSocket listenSocket = new ServerSocket(serverPort);
            while (true) {
                Socket clientSocket = listenSocket.accept();
                System.out.println("accept socket");
                Connection c = new Connection(clientSocket);
            }
        } catch (IOException e) {
            System.out.println("Listen socket:" + e.getMessage());
        }
    }
}

class Connection extends Thread {
    //Scanner in;
    DataInputStream in;
    DataOutputStream out;
    Socket clientSocket;

    public Connection(Socket aClientSocket) {
        try {
            clientSocket = aClientSocket;
            in = new DataInputStream(clientSocket.getInputStream());
             
            //in = new Scanner(clientSocket.getInputStream());
            out = new DataOutputStream(clientSocket.getOutputStream());
            
            System.out.println("create connection thread");
            this.start();
        } catch (IOException e) {
            System.out.println("Connection:" + e.getMessage());
        }
    }

    public void run() {
        // an echo server
        System.out.println("in run");
        /*if(in.hasNext()){
             System.out.println("has data");
        String data = in.next();              // read a line of data from the stream
             System.out.println("get data");
        System.out.println(data);
        }
        
        */
       try {
          
           System.out.println(in.readUTF());
       } catch (IOException ex) {
           Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
       }
        
        
        
        
        //out.writeUTF(data + "from java");
        try {
            clientSocket.close();
        } catch (IOException e) {/*close failed*/
        }

    }
}
