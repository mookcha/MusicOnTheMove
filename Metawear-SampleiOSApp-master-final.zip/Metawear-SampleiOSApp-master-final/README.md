Metawear-SampleiOSApp
========================

Sample iOS App for MetaWear (www.mbientlab.com)

This has been fully updated to Swift 3.0! If you want Obj-C, we preserved the old app in a [branch](https://github.com/mbientlab/Metawear-SampleiOSApp/tree/objc).

## ATTENTION!
We use [CocoaPods](http://cocoapods.org) for dependency management, this means you need to open **MetaWearApiTest.xcworkspace** and not MetaWearApiTest.xcodeproj.

## Getting Started

If you are new to MetaWear please check out our [getting started guide](https://mbientlab.com/gettingstarted).
